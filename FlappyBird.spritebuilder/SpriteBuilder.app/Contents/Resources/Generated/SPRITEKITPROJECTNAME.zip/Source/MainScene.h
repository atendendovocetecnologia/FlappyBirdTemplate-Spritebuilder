//
//  MyScene.h
//  SPRITEKITPROJECTNAME
//

#import <SpriteKit/SpriteKit.h>

@interface MainScene : SKScene

@end
